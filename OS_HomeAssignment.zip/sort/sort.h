#ifndef _SORT_HEADER
#define _SORT_HEADER
/*
    Pre-condition: 
        N is the size of A
    Post-condition:
        Modify the received array to sort it
*/
extern void bubble_sort(int A[], int N);
extern void insertion_sort(int A[], int N);
extern void merge_sort(int A[], int l, int N);
extern void quick_sort(int A[], int l, int N);

#endif
