#include "sort.h"
#include <string.h>
#include <stdio.h>

// Expected command line input of format <INPUT_FILENAME> <ALGORITHM> <OUTPUT_FILENAME>
// <ALGORITHM> is one of "bubble", "merge", "insertion" or "quick"

int main(int argc, char **argv)
{
    if(argc<4)  return 0;

    FILE *fin, *fout;

    fin=fopen(argv[1],"r");
    if (fin == NULL)
    { 
        printf("Cannot open input file\n"); 
        return 0;
    }

    fout=fopen(argv[3],"w");
    if (fout == NULL)
    { 
        printf("Cannot create output file\n"); 
        return 0;
    } 

    int N;
    fscanf(fin, "%d", &N);
    if(N<=0)
    {
        printf("Invalid array size found in input file.\n");
        return 0;
    }
    int arr[N];
    for(int i=0;i<N;i++)
    {
        fscanf(fin,"%d", &arr[i]);
    }

    fclose(fin); // Close input file

    if(strcmp(argv[2],"bubble")==0)
    {
        bubble_sort(arr, N);
    }
    else if(strcmp(argv[2],"merge")==0)
    {
        merge_sort(arr, 0, N);
    }
    else if(strcmp(argv[2],"insertion")==0)
    {
        insertion_sort(arr, N);
    }
    else if(strcmp(argv[2],"quick")==0)
    {
        quick_sort(arr, 0, N);
    }
    else
    {
        printf("Invalid algorithm input. Try one of these: \"bubble\", \"merge\", \"insertion\" or \"quick\" \n");
        return 0;
    }

    for(int i=0;i<N;i++)
    {
        fprintf(fout, "%d ", arr[i]);
    }
    
    fclose(fout);  // Close output file
}