void swap1(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
} 

void bubble_sort(int A[], int N) 
{
    int i, j; 
    for (i = 0; i < N-1; i++)         
        for (j = 0; j < N-i-1; j++)  
            if (A[j] > A[j+1]) 
                swap1(&A[j], &A[j+1]);
}